import Fish


class Moly(Fish.Fish):
    def __init__(self, name, age, x, y, directionH, directionV):
        super().__init__(name, age, x, y, directionH, directionV)
        self.width = 8
        self.height = 3
        self.pattern = [["", "*", "*", "*", "", "", "", "*"], ["*", "*", "*", "*", "*", "*", "*", "*"],
                        ["", "*", "*", "*", "", "", "", "*"]]
        self.rev_pattern = [self.pattern[0][::-1], self.pattern[1][::-1], self.pattern[2][::-1]]

    def get_animal(self):
        """
        returns moly pattern according to it's horizontal direction
        """
        if self.get_directionH() == 0:
            return self.pattern
        else:
            return self.rev_pattern
