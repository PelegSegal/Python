import Animal
import Fish
import Crab
import Shrimp
import Scalar
import Moly
import Ocypode

MAX_ANIMAL_HEIGHT = 5
MAX_ANIMAL_WIDTH = 8
MAX_CRAB_HEIGHT = 4
MAX_CRAB_WIDTH = 7
MAX_FISH_HEIGHT = 5
MAX_FISH_WIDTH = 8
WATERLINE = 3
FEED_AMOUNT = 10
MAX_AGE = 120


def num_input_validity(i):
    """
    checks if input is valid (natural number)
    :param i: the user's input
    :return: rounded int of the input (only if the input is natural number or number.0 (float))
    """
    try:
        if float(i) == round(float(i)):
            return round(float(i))
        else:
            return 0
    except ValueError:
        return 0


class Aqua:
    def __init__(self, aqua_width, aqua_height):
        self.turn = 0
        self.aqua_height = aqua_height
        self.aqua_width = aqua_width
        self.board = []
        self.build_tank()
        self.anim = []

    def build_tank(self):
        """
        builds two dimensional array that represents the aquarium's tank
        """
        for i in range(self.aqua_height):
            self.board.append([' '] * self.aqua_width)
        for i in range(self.aqua_height - 1):
            self.board[i][0] = "|"
            self.board[i][self.aqua_width - 1] = "|"
        for i in range(1, self.aqua_width - 1):
            self.board[2][i] = "~"
            self.board[self.aqua_height - 1][i] = "_"
        self.board[self.aqua_height - 1][0] = '\\'
        self.board[self.aqua_height - 1][self.aqua_width - 1] = "/"

    def print_board(self):
        """
        printing the aquarium tank on screen
        """
        for a in self.anim:
            self.print_animal_on_board(a)
        for r in self.board:
            for c in r:
                print(c, end=" ")
            print()

    def get_board(self):
        """
        returns the array that contains the aquarium
        """
        return self.board

    def get_all_animal(self):
        """
        Returns the array that contains all the animals
        """
        return self.anim

    def is_collision(self, animal):
        """
        Returns True if the next step of the crab is a collision
        """
        if isinstance(animal, Crab.Crab):
            for a in self.anim:
                if isinstance(a, Crab.Crab):
                    if not a.get_directionH() == animal.get_directionH() and \
                            a.x == animal.x + 1 + MAX_CRAB_WIDTH and a.get_directionH() == 0:
                        return True
                    if not a.get_directionH() == animal.get_directionH() and \
                            a.x == animal.x + MAX_CRAB_WIDTH and a.get_directionH() == 0:
                        return True
                    if not a.get_directionH() == animal.get_directionH() and \
                            a.x == animal.x - MAX_CRAB_WIDTH and a.get_directionH() == 1:
                        return True
                    if not a.get_directionH() == animal.get_directionH() and \
                            a.x == animal.x - 1 - MAX_CRAB_WIDTH and a.get_directionH() == 1:
                        return True
                    if a.x == animal.x + MAX_CRAB_WIDTH or a.x == animal.x - MAX_CRAB_WIDTH:
                        if a.get_directionH() == animal.get_directionH() == 1:
                            if a.x == self.aqua_width - 1 - MAX_CRAB_WIDTH:
                                return True
                        if a.get_directionH() == animal.get_directionH() == 0:
                            if a.x == 1:
                                return True
        return False

    def print_animal_on_board(self, animal: Animal):
        """
        prints animal pattern in the board array
        :param animal: the animal that is printed
        """
        if isinstance(animal, Crab.Crab):
            for i in range(animal.height):
                for j in range(animal.width):
                    if animal.get_animal()[i][j] == "*":
                        self.board[animal.y - 1 - animal.height + i][animal.x + j] = "*"
        elif isinstance(animal, Fish.Fish):
            for i in range(animal.height):
                for j in range(animal.width):
                    if animal.get_animal()[i][j] == "*":
                        self.board[animal.y + i][animal.x + j] = "*"

    def delete_animal_from_board(self, animal: Animal):
        """
        deletes animal pattern from the board array
        if animal is no longer alive it also removes it from the array permanently
        :param animal: the animal that is deleted
        """
        if isinstance(animal, Crab.Crab):
            for i in range(animal.height):
                for j in range(animal.width):
                    if animal.get_animal()[i][j] == "*":
                        self.board[animal.y - 1 - animal.height + i][animal.x + j] = " "
        elif isinstance(animal, Fish.Fish):
            for i in range(animal.height):
                for j in range(animal.width):
                    if animal.get_animal()[i][j] == "*":
                        self.board[animal.y + i][animal.x + j] = " "
        if not animal.get_alive():
            self.anim.remove(animal)

    def check_if_free(self, x, y) -> bool:
        """
        method for checking whether the position is empty before inserting a new animal
        """
        if y == self.aqua_height:
            for i in range(MAX_CRAB_HEIGHT):
                for j in range(MAX_CRAB_WIDTH):
                    if self.board[y - 1 - MAX_CRAB_HEIGHT + i][x + j] == "*":
                        print("The place is not available! Please try again later. ")
                        return False
        else:
            for i in range(MAX_FISH_HEIGHT):
                for j in range(MAX_FISH_WIDTH):
                    if self.board[y + i][x + j] == "*":
                        print("The place is not available! Please try again later. ")
                        return False
        return True

    def add_fish(self, name, age, x, y, directionH, directionV, fishtype):
        """
        adding fish into the array.
        if necessary fix's x or/and y coordinate as fish pattern might leak out of aquarium boarders
        """
        if x > self.aqua_width - 1 - MAX_FISH_WIDTH:
            x = self.aqua_width - 1 - MAX_FISH_WIDTH
        if fishtype == "mo":
            moly = Moly.Moly(name, age, x, y, directionH, directionV)
            if moly.y > self.aqua_height - 1 - MAX_CRAB_HEIGHT - moly.height:
                moly.y = self.aqua_height - 1 - MAX_CRAB_HEIGHT - moly.height
            if not self.check_if_free(moly.x, moly.y):
                return False
            else:
                self.anim.append(moly)
                self.print_animal_on_board(moly)
        elif fishtype == "sc":
            scalar = Scalar.Scalar(name, age, x, y, directionH, directionV)
            if scalar.y > self.aqua_height - 1 - MAX_CRAB_HEIGHT - scalar.height:
                scalar.y = self.aqua_height - 1 - MAX_CRAB_HEIGHT - scalar.height
            if not self.check_if_free(scalar.x, scalar.y):
                return False
            else:
                self.anim.append(scalar)
                self.print_animal_on_board(scalar)
        return True

    def add_crab(self, name, age, x, y, directionH, crabtype):
        """
        adding crab into the array
        if necessary fix's x coordinate as crab pattern might leak out of aquarium boarders
        """
        if x > self.aqua_width - 1 - MAX_CRAB_WIDTH:
            x = self.aqua_width - 1 - MAX_CRAB_WIDTH
        if not self.check_if_free(x, y):
            return False
        else:
            if crabtype == "oc":
                ocypode = Ocypode.Ocypode(name, age, x, y, directionH)
                self.anim.append(ocypode)
                self.print_animal_on_board(ocypode)
            elif crabtype == "sh":
                shrimp = Shrimp.Shrimp(name, age, x, y, directionH)
                self.anim.append(shrimp)
                self.print_animal_on_board(shrimp)
        return True

    def left(self, a):
        """
        first the function deletes animal last turn pattern from board with other class method
        if animal collides with aquarium boarder it changes its direction.
        else, reaches Animal.py, animal class "left" method in order to update animal location 1 step left
        finally prints animal pattern, updated to current turn, with other class method
        :param a: the animal
        :return:
        """
        if isinstance(a, Animal.Animal):
            self.delete_animal_from_board(a)
            if a.x == 1:
                a.set_directionH(1)
            else:
                a.left()
            self.print_animal_on_board(a)

    def right(self, a):
        """
        same principle as "left" method
        """
        if isinstance(a, Animal.Animal):
            self.delete_animal_from_board(a)
            if a.x == self.aqua_width - 1 - a.width:
                a.set_directionH(0)
            else:
                a.right()
            self.print_animal_on_board(a)

    def up(self, a):
        """
        same principle as "left" method
        """
        if isinstance(a, Fish.Fish):
            if a.y == WATERLINE:
                a.set_directionV(0)
            else:
                self.delete_animal_from_board(a)
                a.up()
                self.print_animal_on_board(a)

    def down(self, a):
        """
        same principle as "left" method
        """
        if isinstance(a, Fish.Fish):
            if a.y == self.aqua_height - 1 - MAX_CRAB_HEIGHT - a.height:
                a.set_directionV(1)
            else:
                self.delete_animal_from_board(a)
                a.down()
                self.print_animal_on_board(a)

    def next_turn(self):
        """
        Managing a single step:
        first function is dealing with updating, if necessary, animal's age and food
        second, dealing with crab's collision
        finally, moving animal in relevant directions
        """
        death_list = []
        for a in self.anim:
            if self.turn % 10 == 0:
                a.dec_food()
                if not a.get_alive():
                    death_list.append(a)
            if self.turn % 100 == 0:
                a.inc_age()
                if not a.get_alive():
                    death_list.append(a)
        for d in death_list:
            self.delete_animal_from_board(d)

        crab_collision = []
        clean_round = False
        while not clean_round:
            for a in self.anim:
                if isinstance(a, Crab.Crab) and self.is_collision(a):
                    crab_collision.append(a)
            for c in crab_collision:
                self.delete_animal_from_board(c)
                if c.directionH == 1:
                    c.set_directionH(0)
                elif c.directionH == 0:
                    c.set_directionH(1)
                self.print_animal_on_board(c)
            if not crab_collision:
                clean_round = True
            crab_collision = []

        for a in self.anim:
            if a.get_directionH() == 1:
                self.right(a)
            elif a.get_directionH() == 0:
                self.left(a)
            if isinstance(a, Fish.Fish):
                if a.get_directionV() == 1:
                    self.up(a)
                elif a.get_directionV() == 0:
                    self.down(a)
        self.turn += 1

    def print_all(self):
        """
        Prints all the animals in the aquarium
        """
        for a in self.anim:
            print(a)

    def feed_all(self):
        """
        feed all the animals in the aquarium
        """
        for a in self.anim:
            a.add_food(FEED_AMOUNT)

    def add_animal(self, name, age, x, y, directionH, directionV, animaltype):
        """
        adds animal to the array
        """
        if animaltype == 'sc' or animaltype == 'mo':
            return self.add_fish(name, age, x, y, directionH, directionV, animaltype)
        elif animaltype == 'oc' or animaltype == 'sh':
            return self.add_crab(name, age, x, y, directionH, animaltype)
        else:
            return False

    def several_steps(self) -> None:
        """
        Managing several steps
        """
        steps = 0
        while not steps > 0:
            steps = num_input_validity(input("How many steps do you want to take? "))
        count = 0
        while not count == steps:
            self.next_turn()
            count += 1
