import Crab


class Shrimp(Crab.Crab):
    def __init__(self, name, age, x, y, directionH):
        super().__init__(name, age, x, y, directionH)
        self.width = 7
        self.height = 3
        self.pattern = [["*", "", "*", "", "", "", ""], ["", "*", "*", "*", "*", "*", "*"],
                        ["", "", "*", "", "*", "", ""]]
        self.rev_pattern = [self.pattern[0][::-1], self.pattern[1][::-1], self.pattern[2][::-1]]

    def get_animal(self):
        """
        returns shrimp pattern according to it's horizontal direction
        """
        if self.get_directionH() == 0:
            return self.pattern
        else:
            return self.rev_pattern
