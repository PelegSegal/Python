import Crab


class Ocypode(Crab.Crab):
    def __init__(self, name, age, x, y, directionH):
        super().__init__(name, age, x, y, directionH)
        self.width = 7
        self.height = 4
        self.pattern = [["", "*", "", "", "", "*", ""], ["", "", "*", "*", "*", "", ""],
                        ["*", "*", "*", "*", "*", "*", "*"], ["*", "", "", "", "", "", "*"]]
        self.rev_pattern = self.pattern

    def get_animal(self):
        """
        returns ocypode pattern according to it's horizontal direction
        """
        if self.get_directionH() == 0:
            return self.pattern
        else:
            return self.rev_pattern
