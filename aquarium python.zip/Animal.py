MAX_ANIMAL_HEIGHT = 5
MAX_ANIMAL_WIDTH = 8
STARTING_FOOD = 5
MAX_AGE = 120


class Animal:
    def __init__(self, name, age, x, y, directionH):
        self.alive = True
        self.width = MAX_ANIMAL_HEIGHT
        self.height = MAX_ANIMAL_WIDTH
        self.food = STARTING_FOOD
        self.name = name
        self.age = age
        self.x = x
        self.y = y
        self.directionH = directionH  # random 0 - left / 1 - right

    def __str__(self):
        pass

    def get_food(self):
        """
        returns animal food amount
        """
        return self.food

    def get_age(self):
        """
        returns animal age
        """
        return self.age

    def dec_food(self):
        """
        decreasing animal's food amount by 1
        being activated every 10 steps
        """
        self.food -= 1
        if self.food == 0:
            self.starvation()

    def inc_age(self):
        """
        increasing animal's age by 1
        being activated every 100 steps
        """
        self.age += 1
        if self.age == MAX_AGE:
            self.die()

    def right(self):
        """
        reaching set_x method in order to update animal x parameter 1 step right
        """
        self.set_x(self.x + 1)

    def left(self):
        """
        reaching set_x method in order to update animal y parameter 1 step left
        :return:
        """
        self.set_x(self.x - 1)

    def get_position(self):
        """
        returns animal position x, y
        """
        return self.x, self.y

    def set_x(self, x):
        """
        updates animal's x coordinate according to animal's horizontal direction
        :param x: animal's current x parameter
        """
        self.x = x

    def set_y(self, y):
        """
        updates animal's y coordinate according to animal's vertical direction
        :param y: animal's current y parameter
        """
        self.y = y

    def starvation(self):
        pass

    def die(self):
        pass

    def get_directionH(self):
        """
        returns animal's horizontal direction
        """
        return self.directionH

    def set_directionH(self, directionH):
        """
        changing animal's horizontal direction
        :param directionH: animal's current horizontal direction
        """
        self.directionH = directionH

    def get_alive(self):
        """
        returns True if animal still alive
        """
        return self.alive

    def get_size(self):
        """
        returns animal's width and height
        """
        return self.width, self.height

    def get_food_amount(self):
        """
        returns animal's food amount
        """
        return self.food

    def add_food(self, amount):
        """
        adding the requested food amount to animal
        :param amount: amount of food added
        """
        self.food += amount

    def get_animal(self):
        pass
